%% Calculate and Plot Sine Wave
disp(1)

%% Modify Plot Properties
disp(2)