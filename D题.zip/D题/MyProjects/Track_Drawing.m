function tr=Track_Drawing()
load location0;
load location;
for i=1:4
%     figure(2)
    load shg1;
    plot3(location(:,1),location(:,2),shg(:,2));
    view(0,90);hold on;
    
        fid=figure(i);
    m_proj('miller','lon',[99,122],'lat',[2,25]);
    m_grid('linest','none','box','on'); hold on;
    left=1;
    right=1;
    flag=0;
    for j=2:length(location0)
        if(flag==1)
            left=right;
            flag=0;
        end
        if((abs(location0(j,1)-location0(j-1,1))>0.5)||j==length(location0))
            right=j;
            flag=1;
        end
        if(flag==1)
            lon=location0(left:right-1,1); lat=location0(left:right-1,2);
            m_plot(lon,lat,'k','linewidth',1.5); hold on;  % ���ƺ�����
        end
    end
    m_gshhs_f('patch',[0.3,0.3,0.3]); hold on;
    
     title(['���¹켣ͼ']);
%     title(['��',num2str(i),'���ֳ������¹켣ͼ']);
    saveas(fid,['F:\��ģ20180915\MyProjects\MyProjects\���ͼ\�ڶ���\','���¹켣ͼ'],'fig');

end


 