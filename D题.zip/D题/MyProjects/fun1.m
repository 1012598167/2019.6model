function F1=fun1(H,x)
global f0 sigma V0 u0 J;

F1=H(1)+H(2)*f0(J)*cos(sigma(J)*x+V0(J)+u0(J))+H(3)*f0(J)*cos(sigma(J)*x+V0(J)+u0(J));  

end