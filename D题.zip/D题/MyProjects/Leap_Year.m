function Y=LeapYear()%% 1900~2000�е�����
clear; clc;
i=0; LY=[];
for y=1900:2000
    if(((rem(y,4)==0)&(rem(y,100)~=0))|(rem(y,100)==0)&(rem(y,400)==0))
        i=i+1;
        LY=[LY,y];
    end
end
Y=length(LY);
end